@include("partials.language-switcher")
@php
    $lang = session('locale', 'ar');
@endphp
<!DOCTYPE html>
<html lang="{{ $lang }}" dir="{{ $lang === 'ar' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>شركات النقل الإسبانية | Edriouche Truck Job</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f3f6f9;
            color: #17212b;
        }

        header {
            background: linear-gradient(135deg, #102a43, #1f4e79);
            color: white;
            padding: 35px 20px;
            text-align: center;
        }

        header h1 {
            margin: 0 0 10px;
            font-size: 30px;
        }

        header p {
            margin: 0;
            font-size: 17px;
        }

        .container {
            max-width: 1050px;
            margin: 25px auto;
            padding: 0 16px;
        }

        .intro,
        .company {
            background: white;
            border-radius: 16px;
            padding: 22px;
            margin-bottom: 20px;
            box-shadow: 0 5px 18px rgba(0,0,0,0.08);
        }

        .intro h2 {
            color: #102a43;
            margin-top: 0;
        }

        .company {
            position: relative;
            border-right: 6px solid #1f4e79;
        }

        .company h2 {
            margin-top: 0;
            color: #102a43;
        }

        .status {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 20px;
            font-weight: bold;
            margin-bottom: 12px;
        }

        .active {
            background: #e8f5e9;
            color: #176b2c;
        }

        .open {
            background: #e8f1fb;
            color: #155a91;
        }

        .info {
            line-height: 1.9;
        }

        .label {
            font-weight: bold;
            color: #334e68;
        }

        .button {
            display: inline-block;
            background: #102a43;
            color: white;
            text-decoration: none;
            padding: 11px 18px;
            border-radius: 8px;
            margin-top: 12px;
        }

        .button:hover {
            opacity: 0.9;
        }

        .warning {
            background: #fff8e1;
            border-right: 6px solid #d4a72c;
        }

        .legend {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 15px;
        }

        .back {
            background: #52606d;
        }

        footer {
            text-align: center;
            padding: 25px;
            color: #52606d;
        }
@media (max-width:600px){.intro div[style*="grid-template-columns"]{grid-template-columns:repeat(2,1fr)!important;}.intro div[style*="grid-template-columns"] .button{width:auto!important;box-sizing:border-box;}}
.button{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:11px 18px;border-radius:12px;text-decoration:none;font-weight:700;color:#fff!important;background:linear-gradient(135deg,#1f4e79,#2e75b6);box-shadow:0 4px 10px rgba(0,0,0,.15);transition:.25s;box-sizing:border-box;border:1px solid rgba(255,255,255,.25);}.button:hover{transform:translateY(-2px);box-shadow:0 7px 16px rgba(0,0,0,.22);filter:brightness(1.08);}.button:active{transform:scale(.97);}
.company-card{background:#fff;border-radius:16px;padding:20px;margin-bottom:18px;box-shadow:0 5px 15px rgba(0,0,0,.12);border:1px solid #e5e5e5;transition:.25s;}
.company-card:hover{transform:translateY(-3px);box-shadow:0 9px 22px rgba(0,0,0,.18);}
.company-card h3{margin-top:0;color:#1f4e79;font-size:22px;}
.company-card p{line-height:1.8;margin:8px 0;}

    </style>
</head>

<body>

<header>
    <h1>🇪🇸 {{ $lang === "es" ? "Empresas de transporte españolas" : ($lang === "fr" ? "Entreprises de transport espagnoles" : "شركات النقل الإسبانية") }}</h1>
    <p>{{ $lang === "es" ? "Oportunidades para conductores profesionales y candidatura directa a las empresas" : ($lang === "fr" ? "Opportunités pour conducteurs professionnels et candidature directe auprès des entreprises" : "فرص السائقين المهنيين والتقديم المباشر للشركات") }}</p>
</header>

<div class="container">
<div style="text-align:center;margin:20px 0;">
    <a class="button" href="/spain-jobs">🚛 🇪🇸 {{ $lang === "es" ? "Ofertas de trabajo en España" : ($lang === "fr" ? "Offres d’emploi en Espagne" : "عروض العمل في إسبانيا") }}</a>
<a class="button" href="/spain-law">⚖️ 🇪🇸 {{ $lang === "es" ? "Ley española para el conductor profesional" : ($lang === "fr" ? "Loi espagnole pour le conducteur professionnel" : "القانون الإسباني للسائق المهني") }}</a>
</div>

    <div class="intro">
        <div class="intro" style="border-top:6px solid #d4af37;background:linear-gradient(135deg,#ffffff,#f8fafc);">
            @if($lang === 'es')
                <h2>🚛 No mires solo el camión… mira a la persona que está detrás del volante.</h2>
                <h3>Detrás de cada camión hay una historia.</h3>
                <p>El conductor no conduce solamente un camión… lleva una responsabilidad y una vida entera sobre sus hombros.</p>
                <p>A veces no pudo estar en celebraciones ni en funerales… porque la carretera lo llamaba y detrás de él había una carga, una responsabilidad y un deber profesional.</p>
                <p><strong>Honestidad • Confianza • Responsabilidad • Deber profesional</strong></p>
                <p><strong>Detrás de cada camión que llega a su destino, hay una persona que ha hecho muchos sacrificios para que llegue con seguridad.</strong></p>
                <p>Por eso creamos <strong>Edriouche Truck Job</strong>: no solo para buscar trabajo, sino para defender el respeto por la profesión de conductor, ayudar al conductor a encontrar una oportunidad real, conocer sus derechos y protegerse de intermediarios y falsas promesas.</p>
                <p><strong>🇲🇦 De Marruecos a Europa… queremos que el conductor llegue con dignidad, igual que su camión llega con seguridad.</strong></p>
                <p style="font-size:22px;"><strong>El conductor profesional merece respeto. 🚛❤️</strong></p>
            @elseif($lang === 'fr')
                <h2>🚛 Ne regardez pas seulement le camion… regardez la personne qui est derrière le volant.</h2>
                <h3>Derrière chaque camion, il y a une histoire.</h3>
                <p>Le conducteur ne conduit pas seulement un camion… il porte une responsabilité et toute une vie sur ses épaules.</p>
                <p>Parfois, il n'a pas pu être présent aux fêtes ni aux funérailles… parce que la route l'appelait et qu'il avait derrière lui une cargaison, une responsabilité et un devoir professionnel.</p>
                <p><strong>Honnêteté • Confiance • Responsabilité • Devoir professionnel</strong></p>
                <p><strong>Derrière chaque camion qui arrive à destination, il y a une personne qui a fait de nombreux sacrifices pour qu'il arrive en toute sécurité.</strong></p>
                <p>C'est pourquoi nous avons créé <strong>Edriouche Truck Job</strong> : non seulement pour chercher un emploi, mais pour défendre le respect de la profession de conducteur, aider le conducteur à trouver une véritable opportunité, connaître ses droits et se protéger des intermédiaires et des fausses promesses.</p>
                <p><strong>🇲🇦 Du Maroc vers l'Europe… nous voulons que le conducteur arrive avec dignité, tout comme son camion arrive en toute sécurité.</strong></p>
                <p style="font-size:22px;"><strong>Le conducteur professionnel mérite le respect. 🚛❤️</strong></p>
            @else
                <h2>🚛 لا تنظر فقط إلى الشاحنة… انظر إلى الإنسان الذي يجلس خلف المقود.</h2>
                <h3>خلف كل شاحنة قصة.</h3>
                <p>السائق لا يقود شاحنة فقط… بل يحمل على كتفيه مسؤولية وحياة كاملة.</p>
                <p>أحيانًا لم يستطع أن يكون حاضرًا في المناسبات أو الجنازات… لأن الطريق كان يناديه، وخلفه حمولة ومسؤولية وواجب مهني.</p>
                <p><strong>الأمانة • الثقة • المسؤولية • الواجب المهني</strong></p>
                <p><strong>خلف كل شاحنة تصل إلى وجهتها، هناك إنسان قدّم الكثير من التضحيات حتى تصل بأمان.</strong></p>
                <p>لهذا أنشأنا <strong>Edriouche Truck Job</strong>: ليس فقط للبحث عن عمل، بل للدفاع عن احترام مهنة السائق، ومساعدة السائق على العثور على فرصة حقيقية، ومعرفة حقوقه، وحمايته من الوسطاء والوعود الكاذبة.</p>
                <p><strong>🇲🇦 من المغرب إلى أوروبا… نريد أن يصل السائق بكرامة، كما تصل شاحنته بأمان.</strong></p>
                <p style="font-size:22px;"><strong>السائق المهني يستحق الاحترام. 🚛❤️</strong></p>
            @endif
        </div>

        <h2>🚛 {{ $lang === "es" ? "Empresas de transporte y oportunidades de candidatura en España" : ($lang === "fr" ? "Entreprises de transport et opportunités de candidature en Espagne" : "شركات النقل وفرص التقديم في إسبانيا") }}</h2>

        <p>
            {{ $lang === 'es' ? 'Hemos reunido esta lista para ayudar al conductor marroquí a contactar directamente con empresas españolas, lejos de intermediarios y ofertas poco fiables.' : ($lang === 'fr' ? 'Nous avons réuni cette liste pour aider le conducteur marocain à contacter directement les entreprises espagnoles, loin des intermédiaires et des offres peu fiables.' : 'جمعنا هذه القائمة لمساعدة السائق المغربي على الوصول إلى شركات النقل واللوجستيك في إسبانيا مباشرة، والتعرف على طرق التقديم الرسمية بعيدًا عن الوسطاء والوعود الكاذبة.') }}
        </p>

        <p>
            {{ $lang === 'es' ? 'Distinguimos claramente entre una contratación activa y una empresa que solo acepta candidaturas.' : ($lang === 'fr' ? 'Nous distinguons clairement entre un recrutement actif et une entreprise qui accepte uniquement les candidatures.' : 'نميز بوضوح بين الوظيفة النشطة وبين الشركة التي تستقبل الترشيحات فقط.') }}
        </p>

        <div class="legend">
            <span class="status active">🟢 {{ $lang === 'es' ? 'Contratación activa' : ($lang === 'fr' ? 'Recrutement actif' : 'توظيف نشط حاليًا') }}</span>
            <span class="status open">🔵 {{ $lang === 'es' ? 'Candidatura abierta' : ($lang === 'fr' ? 'Candidature ouverte' : 'ترشيح مفتوح') }}</span>
        </div>
    </div>

    @php
    $lang = session('locale', 'ar');
@endphp

    <!-- 1 JCARRION -->
    <div class="company-card">
        <span class="status active">🟢 {{ $lang === 'es' ? 'Contratación activa' : ($lang === 'fr' ? 'Recrutement actif' : 'توظيف نشط حاليًا') }}</span>
        <h2>🏢 JCARRION</h2>
        <div class="info">
            <p><span class="label">📍 {{ $lang === 'es' ? 'Ámbito:' : ($lang === 'fr' ? 'Domaine :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'España – transporte nacional e internacional' : ($lang === 'fr' ? 'Espagne – transport national et international' : 'إسبانيا – نقل وطني ودولي') }}</p>
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Requisito:' : ($lang === 'fr' ? 'Permis requis :' : 'المطلوب:') }}</span> C+E</p>
            <p><span class="label">🎓 {{ $lang === 'es' ? 'Requisitos:' : ($lang === 'fr' ? 'Exigences :' : 'المتطلبات:') }}</span> CAP + {{ $lang === 'es' ? 'tarjeta de tacógrafo digital' : ($lang === 'fr' ? 'carte tachygraphe numérique' : 'بطاقة التاكغراف الرقمي') }}</p>
            <p><span class="label">⭐ {{ $lang === 'es' ? 'Nota:' : ($lang === 'fr' ? 'Note :' : 'ملاحظة:') }}</span> {{ $lang === 'es' ? 'Hay ofertas actuales y algunas aceptan conductores sin experiencia, según la oferta.' : ($lang === 'fr' ? 'Des offres sont disponibles et certaines acceptent les conducteurs sans expérience, selon l’offre.' : 'توجد عروض حالية، وبعضها يقبل السائقين دون خبرة حسب العرض.') }}</p>
        </div>
        <a class="button" href="https://ofertas.jcarrion.es/jobs" target="_blank">🔗 {{ $lang === 'es' ? 'Candidatura oficial' : ($lang === 'fr' ? 'Candidature officielle' : 'التقديم الرسمي') }}</a>
    </div>

    <!-- 2 Doseguer -->
    <div class="company-card">
        <span class="status active">🟢 {{ $lang === 'es' ? 'Contratación activa' : ($lang === 'fr' ? 'Recrutement actif' : 'توظيف نشط حاليًا') }}</span>
        <h2>🏢 Doseguer</h2>
        <div class="info">
            <p><span class="label">📍 {{ $lang === 'es' ? 'Zonas:' : ($lang === 'fr' ? 'Zones :' : 'المناطق:') }}</span> Almería · Granada · Murcia</p>
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Actividad:' : ($lang === 'fr' ? 'Activité :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'Transporte frigorífico y mercancía general' : ($lang === 'fr' ? 'Transport frigorifique et marchandises générales' : 'نقل مبرد وبضائع عامة') }}</p>
            <p><span class="label">🌍 {{ $lang === 'es' ? 'Rutas:' : ($lang === 'fr' ? 'Itinéraires :' : 'المسارات:') }}</span> {{ $lang === 'es' ? 'Nacionales e internacionales' : ($lang === 'fr' ? 'Nationales et internationales' : 'وطنية ودولية') }}</p>
            <p><span class="label">🎓 {{ $lang === 'es' ? 'Requisitos:' : ($lang === 'fr' ? 'Exigences :' : 'المتطلبات:') }}</span> C+E + CAP + {{ $lang === 'es' ? 'tarjeta de tacógrafo digital' : ($lang === 'fr' ? 'carte tachygraphe numérique' : 'بطاقة تاكوغراف رقمي') }}</p>
        </div>
        <a class="button" href="https://www.doseguer.com/trabaja-con-nosotros/" target="_blank">🔗 {{ $lang === 'es' ? 'Candidatura oficial' : ($lang === 'fr' ? 'Candidature officielle' : 'التقديم الرسمي') }}</a>
    </div>

    <!-- 3 STEF -->
    <div class="company-card">
        <span class="status active">🟢 {{ $lang === 'es' ? 'Contratación activa' : ($lang === 'fr' ? 'Recrutement actif' : 'توظيف نشط حاليًا') }}</span>
        <h2>🏢 STEF</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Actividad:' : ($lang === 'fr' ? 'Activité :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'Transporte y logística, especialmente productos alimentarios refrigerados' : ($lang === 'fr' ? 'Transport et logistique, notamment produits alimentaires réfrigérés' : 'النقل واللوجستيك، خصوصًا المنتجات الغذائية المبردة') }}</p>
            <p><span class="label">🚚 {{ $lang === 'es' ? 'Puestos:' : ($lang === 'fr' ? 'Postes :' : 'الوظائف:') }}</span> {{ $lang === 'es' ? 'Conductores C+E según el centro de trabajo' : ($lang === 'fr' ? 'Chauffeurs C+E selon le site' : 'سائقو C+E حسب مركز العمل') }}</p>
            <p><span class="label">🎓 {{ $lang === 'es' ? 'Requisitos:' : ($lang === 'fr' ? 'Exigences :' : 'المتطلبات:') }}</span> {{ $lang === 'es' ? 'Según la oferta' : ($lang === 'fr' ? 'Selon l’offre' : 'تختلف حسب الإعلان') }}</p>
        </div>
        <a class="button" href="https://www.stef.jobs/" target="_blank">🔗 {{ $lang === 'es' ? 'Empleos oficiales STEF' : ($lang === 'fr' ? 'Emplois officiels STEF' : 'وظائف STEF الرسمية') }}</a>
    </div>

    <!-- 4 CONTANK -->
    <div class="company-card">
        <span class="status active">🟢 {{ $lang === 'es' ? 'Contratación activa' : ($lang === 'fr' ? 'Recrutement actif' : 'توظيف نشط حاليًا') }}</span>
        <h2>🏢 CONTANK</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Actividad:' : ($lang === 'fr' ? 'Activité :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'Transporte de mercancías y remolques' : ($lang === 'fr' ? 'Transport de marchandises et remorques' : 'نقل البضائع والمقطورات') }}</p>
            <p><span class="label">🚚 {{ $lang === 'es' ? 'Requisito:' : ($lang === 'fr' ? 'Permis requis :' : 'المطلوب:') }}</span> C+E</p>
            <p><span class="label">🎓 {{ $lang === 'es' ? 'Requisitos:' : ($lang === 'fr' ? 'Exigences :' : 'المتطلبات:') }}</span> CAP + {{ $lang === 'es' ? 'tarjeta de tacógrafo' : ($lang === 'fr' ? 'carte tachygraphe' : 'بطاقة تاكوغراف') }}</p>
        </div>
        <a class="button" href="https://contank.com/career/" target="_blank">🔗 {{ $lang === 'es' ? 'Candidatura oficial' : ($lang === 'fr' ? 'Candidature officielle' : 'التقديم الرسمي') }}</a>
    </div>

    <!-- 5 Grupo SGT -->
    <div class="company-card">
        <span class="status open">🔵 {{ $lang === 'es' ? 'Candidatura abierta' : ($lang === 'fr' ? 'Candidature ouverte' : 'ترشيح مفتوح') }}</span>
        <h2>🏢 Grupo SGT</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Actividad:' : ($lang === 'fr' ? 'Activité :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'Transporte nacional e internacional y logística' : ($lang === 'fr' ? 'Transport national et international et logistique' : 'النقل الوطني والدولي واللوجستيك') }}</p>
            <p><span class="label">🚚 {{ $lang === 'es' ? 'Requisito:' : ($lang === 'fr' ? 'Permis requis :' : 'المطلوب:') }}</span> C+E {{ $lang === 'es' ? 'según el puesto' : ($lang === 'fr' ? 'selon le poste' : 'حسب الوظيفة') }}</p>
            <p><span class="label">🎓 {{ $lang === 'es' ? 'Requisitos:' : ($lang === 'fr' ? 'Exigences :' : 'المتطلبات:') }}</span> CAP + {{ $lang === 'es' ? 'experiencia según el puesto' : ($lang === 'fr' ? 'expérience selon le poste' : 'خبرة حسب الوظيفة') }}</p>
        </div>
        <a class="button" href="https://www.gruposgt.com/trabaja-con-nosotros" target="_blank">🔗 {{ $lang === 'es' ? 'Candidatura oficial' : ($lang === 'fr' ? 'Candidature officielle' : 'التقديم الرسمي') }}</a>
    </div>

    <!-- 6 Primafrio -->
    <div class="company-card">
        <span class="status open">🔵 {{ $lang === 'es' ? 'Candidatura abierta' : ($lang === 'fr' ? 'Candidature ouverte' : 'ترشيح مفتوح') }}</span>
        <h2>🏢 Primafrio</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Actividad:' : ($lang === 'fr' ? 'Activité :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'Transporte frigorífico y logística' : ($lang === 'fr' ? 'Transport frigorifique et logistique' : 'النقل المبرد واللوجستيك') }}</p>
            <p><span class="label">🌍 {{ $lang === 'es' ? 'Ámbito geográfico:' : ($lang === 'fr' ? 'Zone géographique :' : 'المجال الجغرافي:') }}</span> {{ $lang === 'es' ? 'España y Europa' : ($lang === 'fr' ? 'Espagne et Europe' : 'إسبانيا وأوروبا') }}</p>
            <p><span class="label">👨‍✈️ {{ $lang === 'es' ? 'Para conductores:' : ($lang === 'fr' ? 'Pour les chauffeurs :' : 'للسائق:') }}</span> {{ $lang === 'es' ? 'Se puede enviar una candidatura directa a la empresa.' : ($lang === 'fr' ? 'Une candidature directe peut être envoyée à l’entreprise.' : 'يمكن إرسال طلب ترشيح مباشر عبر الشركة.') }}</p>
        </div>
        <a class="button" href="https://www.primafrio.com/trabajo/" target="_blank">🔗 {{ $lang === 'es' ? 'Candidatura oficial' : ($lang === 'fr' ? 'Candidature officielle' : 'التقديم الرسمي') }}</a>
    </div>

    <!-- 7 Logista -->
    <div class="company-card">
        <span class="status open">🔵 {{ $lang === 'es' ? 'Candidatura abierta' : ($lang === 'fr' ? 'Candidature ouverte' : 'ترشيح مفتوح') }}</span>
        <h2>🏢 Logista</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Actividad:' : ($lang === 'fr' ? 'Activité :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'Transporte, logística y distribución' : ($lang === 'fr' ? 'Transport, logistique et distribution' : 'النقل واللوجستيك والتوزيع') }}</p>
            <p><span class="label">👨‍✈️ {{ $lang === 'es' ? 'Para conductores:' : ($lang === 'fr' ? 'Pour les chauffeurs :' : 'للسائقين:') }}</span> {{ $lang === 'es' ? 'Canales oficiales de contacto y candidatura según la actividad.' : ($lang === 'fr' ? 'Canaux officiels de contact et de candidature selon l’activité.' : 'توجد قنوات رسمية للتواصل والترشيح حسب النشاط.') }}</p>
        </div>
        <a class="button" href="https://www.logista.com/" target="_blank">🔗 {{ $lang === 'es' ? 'Sitio oficial' : ($lang === 'fr' ? 'Site officiel' : 'الموقع الرسمي') }}</a>
    </div>

    <!-- 8 Grupo Hiemesa -->
    <div class="company-card">
        <span class="status active">🟢 {{ $lang === 'es' ? 'Contratación activa' : ($lang === 'fr' ? 'Recrutement actif' : 'توظيف نشط حاليًا') }}</span>
        <h2>🏢 Grupo Hiemesa</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Actividad:' : ($lang === 'fr' ? 'Activité :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'Transporte de mercancías y remolques' : ($lang === 'fr' ? 'Transport de marchandises et remorques' : 'نقل البضائع والمقطورات') }}</p>
            <p><span class="label">🚚 {{ $lang === 'es' ? 'Requisito:' : ($lang === 'fr' ? 'Permis requis :' : 'المطلوب:') }}</span> C+E</p>
            <p><span class="label">🎓 {{ $lang === 'es' ? 'Requisitos:' : ($lang === 'fr' ? 'Exigences :' : 'المتطلبات:') }}</span> CAP + {{ $lang === 'es' ? 'tarjeta de tacógrafo' : ($lang === 'fr' ? 'carte tachygraphe' : 'بطاقة تاكوغراف') }}</p>
        </div>
        <a class="button" href="https://www.hiemesa.com/Trabaja" target="_blank">🔗 {{ $lang === 'es' ? 'Candidatura oficial' : ($lang === 'fr' ? 'Candidature officielle' : 'التقديم الرسمي') }}</a>
    </div>

    <!-- 9 Disfrimur -->
    <div class="company-card">
        <span class="status open">🔵 {{ $lang === 'es' ? 'Candidatura abierta' : ($lang === 'fr' ? 'Candidature ouverte' : 'ترشيح مفتوح') }}</span>
        <h2>🏢 Disfrimur</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Actividad:' : ($lang === 'fr' ? 'Activité :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'Transporte frigorífico y logística' : ($lang === 'fr' ? 'Transport frigorifique et logistique' : 'النقل المبرد واللوجستيك') }}</p>
            <p><span class="label">🎓 {{ $lang === 'es' ? 'Ventaja:' : ($lang === 'fr' ? 'Avantage :' : 'ميزة مهمة:') }}</span> {{ $lang === 'es' ? 'La empresa cuenta con un programa Escuela de Conductores para formar conductores.' : ($lang === 'fr' ? 'L’entreprise dispose d’un programme Escuela de Conductores pour former les chauffeurs.' : 'لدى الشركة برنامج Escuela de Conductores لتكوين السائقين.') }}</p>
            <p><span class="label">🚚 {{ $lang === 'es' ? 'Categorías:' : ($lang === 'fr' ? 'Catégories :' : 'الفئات:') }}</span> C y C+E {{ $lang === 'es' ? 'según el programa y las oportunidades disponibles.' : ($lang === 'fr' ? 'selon le programme et les opportunités disponibles.' : 'حسب البرنامج والفرص المتاحة.') }}</p>
        </div>
        <a class="button" href="https://disfrimur.com/rrhh/trabaja-con-nosotros/" target="_blank">🔗 {{ $lang === 'es' ? 'Sitio oficial' : ($lang === 'fr' ? 'Site officiel' : 'الموقع الرسمي') }}</a>
    </div>


    <!-- 10 Eurotransportes -->
    <div class="company-card">
        <span class="status open">🔵 {{ $lang === 'es' ? 'Envío de CV' : ($lang === 'fr' ? 'Envoi de CV' : 'إرسال السيرة الذاتية') }}</span>
        <h2>🏢 Eurotransportes</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Actividad:' : ($lang === 'fr' ? 'Activité :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'Transporte y logística por carretera' : ($lang === 'fr' ? 'Transport et logistique routière' : 'النقل واللوجستيك عبر الطرق') }}</p>
            <p><span class="label">👨‍✈️ {{ $lang === 'es' ? 'Para conductores:' : ($lang === 'fr' ? 'Pour les chauffeurs :' : 'للسائقين:') }}</span> {{ $lang === 'es' ? 'Buscan conductores de camión y permiten enviar CV mediante su formulario oficial.' : ($lang === 'fr' ? 'Recherche de chauffeurs routiers avec dépôt de CV via le formulaire officiel.' : 'تستقبل طلبات سائقي الشاحنات عبر نموذجها الرسمي.') }}</p>
        </div>
        <a class="button" href="https://www.eurotransportes.com/es/empleo" target="_blank" rel="noopener">🔗 {{ $lang === 'es' ? 'Empleo oficial' : ($lang === 'fr' ? 'Emploi officiel' : 'التوظيف الرسمي') }}</a>
    </div>

    <!-- 11 Fiatrans -->
    <div class="company-card">
        <span class="status active">🟢 {{ $lang === 'es' ? 'Oferta de conductor' : ($lang === 'fr' ? 'Offre chauffeur' : 'عرض للسائقين') }}</span>
        <h2>🏢 Fiatrans</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Puesto:' : ($lang === 'fr' ? 'Poste :' : 'الوظيفة:') }}</span> {{ $lang === 'es' ? 'Conductor/a de tráiler' : ($lang === 'fr' ? 'Conducteur de semi-remorque' : 'سائق شاحنة مقطورة') }}</p>
            <p><span class="label">🚚 {{ $lang === 'es' ? 'Requisitos:' : ($lang === 'fr' ? 'Exigences :' : 'المتطلبات:') }}</span> C+E + CAP</p>
        </div>
        <a class="button" href="https://www.fiatrans.com/trabaja-con-nosotros" target="_blank" rel="noopener">🔗 {{ $lang === 'es' ? 'Oferta y candidatura' : ($lang === 'fr' ? 'Offre et candidature' : 'العرض والتقديم') }}</a>
    </div>

    <!-- 12 Transportes Argo -->
    <div class="company-card">
        <span class="status open">🔵 {{ $lang === 'es' ? 'Recepción de CV' : ($lang === 'fr' ? 'Réception de CV' : 'استقبال السير الذاتية') }}</span>
        <h2>🏢 Transportes Argo</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Puesto:' : ($lang === 'fr' ? 'Poste :' : 'الوظيفة:') }}</span> {{ $lang === 'es' ? 'Chófer / Conductor profesional' : ($lang === 'fr' ? 'Chauffeur professionnel' : 'سائق مهني') }}</p>
            <p><span class="label">🚚 {{ $lang === 'es' ? 'Requisitos:' : ($lang === 'fr' ? 'Exigences :' : 'المتطلبات:') }}</span> C+E + {{ $lang === 'es' ? '2 años de experiencia' : ($lang === 'fr' ? '2 ans d’expérience' : 'سنتان من الخبرة') }}</p>
            <p><span class="label">📍</span> Madrid · Barcelona · Valencia · Algeciras</p>
        </div>
        <a class="button" href="https://argovlc.es/trabaja-con-nosotros/" target="_blank" rel="noopener">🔗 {{ $lang === 'es' ? 'Trabaja con nosotros' : ($lang === 'fr' ? 'Travailler avec nous' : 'العمل معنا') }}</a>
    </div>

    <!-- 13 Transportes Zaivan -->
    <div class="company-card">
        <span class="status active">🟢 {{ $lang === 'es' ? 'Búsqueda de conductores' : ($lang === 'fr' ? 'Recherche de chauffeurs' : 'بحث عن سائقين') }}</span>
        <h2>🏢 Transportes Zaivan</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Actividad:' : ($lang === 'fr' ? 'Activité :' : 'المجال:') }}</span> {{ $lang === 'es' ? 'Transporte frigorífico nacional' : ($lang === 'fr' ? 'Transport frigorifique national' : 'النقل المبرد الوطني') }}</p>
            <p><span class="label">🚚 {{ $lang === 'es' ? 'Requisitos:' : ($lang === 'fr' ? 'Exigences :' : 'المتطلبات:') }}</span> {{ $lang === 'es' ? 'Carnet C + CAP + tacógrafo digital' : ($lang === 'fr' ? 'Permis C + CAP + tachygraphe numérique' : 'رخصة C + CAP + تاكوغراف رقمي') }}</p>
        </div>
        <a class="button" href="https://www.transporteszaivan.es/trabaja-con-nosotros/" target="_blank" rel="noopener">🔗 {{ $lang === 'es' ? 'Oferta oficial' : ($lang === 'fr' ? 'Offre officielle' : 'العرض الرسمي') }}</a>
    </div>

    <!-- 14 Domingo Laredo -->
    <div class="company-card">
        <span class="status open">🔵 {{ $lang === 'es' ? 'Puestos para conductores' : ($lang === 'fr' ? 'Postes chauffeurs' : 'وظائف للسائقين') }}</span>
        <h2>🏢 Domingo Laredo</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Puestos:' : ($lang === 'fr' ? 'Postes :' : 'الوظائف:') }}</span> {{ $lang === 'es' ? 'Conductores de camiones de 3 ejes y bañeras con experiencia.' : ($lang === 'fr' ? 'Chauffeurs de camions 3 essieux et bennes avec expérience.' : 'سائقو شاحنات 3 محاور وشاحنات قلاب مع الخبرة.') }}</p>
            <p><span class="label">📍 {{ $lang === 'es' ? 'Zonas:' : ($lang === 'fr' ? 'Zones :' : 'المناطق:') }}</span> Madrid · Granada · Palencia · Almería</p>
        </div>
        <a class="button" href="https://dlaredo.com/trabaja-con-nosotros/" target="_blank" rel="noopener">🔗 {{ $lang === 'es' ? 'Trabajo oficial' : ($lang === 'fr' ? 'Emploi officiel' : 'العمل الرسمي') }}</a>
    </div>

    <!-- 15 Danuri Logistics -->
    <div class="company-card">
        <span class="status open">🔵 {{ $lang === 'es' ? 'Conductores en plantilla' : ($lang === 'fr' ? 'Chauffeurs salariés' : 'سائقون بعقد') }}</span>
        <h2>🏢 Danuri Logistics</h2>
        <div class="info">
            <p><span class="label">🚛 {{ $lang === 'es' ? 'Perfil:' : ($lang === 'fr' ? 'Profil :' : 'الملف المطلوب:') }}</span> C+E + CAP + {{ $lang === 'es' ? 'tarjeta de tacógrafo digital' : ($lang === 'fr' ? 'carte tachygraphe numérique' : 'بطاقة تاكوغراف رقمية') }}</p>
            <p><span class="label">📍</span> {{ $lang === 'es' ? 'Madrid y rutas por España y Portugal' : ($lang === 'fr' ? 'Madrid et itinéraires en Espagne et au Portugal' : 'مدريد ومسارات في إسبانيا والبرتغال') }}</p>
        </div>
        <a class="button" href="https://danurilogistics.com/trabaja-con-nosotros.html" target="_blank" rel="noopener">🔗 {{ $lang === 'es' ? 'Trabaja con nosotros' : ($lang === 'fr' ? 'Travailler avec nous' : 'العمل معنا') }}</a>
    </div>

    <div class="intro" style="border-top:5px solid #1f4e79;">
        <h2>🇪🇸 {{ $lang === "es" ? "Guía del conductor marroquí en España" : ($lang === "fr" ? "Guide du conducteur marocain en Espagne" : "دليل السائق المغربي في إسبانيا") }}</h2>
        <p>{{ $lang === "es" ? "Todo lo que el conductor necesita para buscar empleo, formación e información fiable en un solo lugar." : ($lang === "fr" ? "Tout ce dont le conducteur a besoin pour rechercher un emploi, une formation et des informations fiables au même endroit." : "كل ما يحتاجه السائق للبحث عن عمل وتكوين ومعلومات موثوقة في مكان واحد.") }}</p>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:15px;margin-top:20px;">
            <a class="button" href="/jobs">{{ $lang === "es" ? "💼 Ofertas de trabajo" : ($lang === "fr" ? "💼 Offres d’emploi" : "💼 عروض العمل") }}</a>
            <a class="button" href="/training">{{ $lang === "es" ? "🎓 Formación y capacitación" : ($lang === "fr" ? "🎓 Formation et perfectionnement" : "🎓 التكوين والتدريب") }}</a>
            <a class="button" href="/cap">{{ $lang === "es" ? "🇪🇸 Centros CAP" : ($lang === "fr" ? "🇪🇸 Centres CAP" : "🇪🇸 مراكز CAP") }}</a>
            <a class="button" href="/spain">{{ $lang === "es" ? "🇪🇸 Guía de trabajo en España" : ($lang === "fr" ? "🇪🇸 Guide du travail en Espagne" : "🇪🇸 دليل العمل في إسبانيا") }}</a>
            <a class="button" href="/driver-documents">{{ $lang === "es" ? "🪪 Documentos del conductor" : ($lang === "fr" ? "🪪 Documents du conducteur" : "🪪 وثائق السائق") }}</a>
            <a class="button" href="/europe-documents">{{ $lang === "es" ? "📑 Documentos europeos" : ($lang === "fr" ? "📑 Documents européens" : "📑 وثائق أوروبا") }}</a>
            <a class="button" href="/europe-rules">{{ $lang === "es" ? "🕐 Reglas de conducción y descanso" : ($lang === "fr" ? "🕐 Règles de conduite et de repos" : "🕐 قوانين القيادة والراحة") }}</a>
            <a class="button" href="/tachograph-guide">{{ $lang === "es" ? "⏱️ Guía del tacógrafo" : ($lang === "fr" ? "⏱️ Guide du tachygraphe" : "⏱️ دليل التاكوغراف") }}</a>
            <a class="button" href="/cv-builder">{{ $lang === "es" ? "📝 Crear CV del conductor" : ($lang === "fr" ? "📝 Créer le CV du conducteur" : "📝 إنشاء CV للسائق") }}</a>
        </div>
    </div>

    <div class="intro" style="border-top:5px solid #d4af37;">
        <h2>🚛 {{ $lang === "es" ? "Tipos de transporte que buscan los conductores" : ($lang === "fr" ? "Types de transport recherchés par les conducteurs" : "أنواع النقل التي يبحث عنها السائقون") }}</h2>
        <p>{{ $lang === "es" ? "Transporte internacional • transporte nacional • transporte frigorífico • logística • materiales de construcción • contenedores • transporte de mercancías • transporte especializado" : ($lang === "fr" ? "Transport international • transport national • transport frigorifique • logistique • matériaux de construction • conteneurs • transport de marchandises • transport spécialisé" : "النقل الدولي • النقل الوطني • النقل المبرد • اللوجستيك • مواد البناء • الحاويات • نقل البضائع • النقل المتخصص") }}</p>
        <p><strong>{{ $lang === "es" ? "Nota:" : ($lang === "fr" ? "Remarque :" : "ملاحظة:") }}</strong> {{ $lang === "es" ? "Añadimos cada tipo de transporte cuando disponemos de información fiable y un enlace oficial." : ($lang === "fr" ? "Nous ajoutons chaque type de transport lorsque nous disposons d’informations fiables et d’un lien officiel." : "نضيف كل نوع من النقل عندما تتوفر لدينا معلومات موثوقة ورابط رسمي.") }}</p>
    </div>

    <div class="intro" style="border-top:5px solid #2e7d32;">
        <h2>🏙️ {{ $lang === "es" ? "Ciudades y zonas de transporte en España" : ($lang === "fr" ? "Villes et zones de transport en Espagne" : "مدن ومناطق النقل في إسبانيا") }}</h2>
        <p>{{ $lang === "es" ? "Madrid • Barcelona • Valencia • Zaragoza • Murcia • Málaga • Sevilla • Bilbao • Almería • Huelva • Madrid y otras zonas logísticas" : ($lang === "fr" ? "Madrid • Barcelone • Valence • Saragosse • Murcie • Malaga • Séville • Bilbao • Almería • Huelva • Madrid et autres zones logistiques" : "مدريد • برشلونة • فالنسيا • سرقسطة • مورسيا • مالقة • إشبيلية • بلباو • ألميريا • هويلفا • مدريد والمناطق اللوجستية الأخرى") }}</p>
        <p>{{ $lang === "es" ? "Puedes buscar una empresa por ciudad a través de las páginas oficiales de empleo de las empresas." : ($lang === "fr" ? "Vous pouvez rechercher une entreprise par ville via les pages officielles de recrutement des entreprises." : "يمكنك البحث عن الشركة حسب المدينة من خلال صفحات التوظيف الرسمية للشركات.") }}</p>
    </div>

    <div class="intro" style="border-top:5px solid #7b1fa2;">
        <h2>🔗 {{ $lang === "es" ? "Fuentes oficiales para el conductor" : ($lang === "fr" ? "Sources officielles pour le conducteur" : "مصادر رسمية للسائق") }}</h2>
        <p>{{ $lang === "es" ? "Utilizamos, siempre que sea posible, fuentes oficiales y no intermediarios ni cuentas desconocidas." : ($lang === "fr" ? "Nous nous appuyons autant que possible sur les sources officielles, et non sur des intermédiaires ou des comptes inconnus." : "نعتمد قدر الإمكان على المصادر الرسمية، وليس على الوسطاء أو الحسابات المجهولة.") }}</p>
        <p>
            <a class="button" href="https://sede.transportes.gob.es/" target="_blank">🇪🇸 {{ $lang === "es" ? "Ministerio de Transportes de España" : ($lang === "fr" ? "Ministère espagnol des Transports" : "وزارة النقل الإسبانية") }}</a>
            <a class="button" href="https://eures.europa.eu/" target="_blank">🇪🇺 EURES</a>
        </p>
    </div>


    <div class="intro warning">
        <h2>⚠️ {{ $lang === "es" ? "Aviso para el conductor marroquí" : ($lang === "fr" ? "Avertissement au conducteur marocain" : "تنبيه للسائق المغربي") }}</h2>

        <p>
            Edriouche Truck Job لا يبيع عقود العمل ولا يطلب من السائق
            دفع المال مقابل الحصول على وظيفة.
        </p>

        <p>
            {{ $lang === "es" ? "Antes de enviar tus documentos o pagar cualquier cantidad" : ($lang === "fr" ? "Avant d’envoyer vos documents ou de payer une quelconque somme" : "قبل إرسال وثائقك أو دفع أي مبلغ") }}، تحقق من الشركة ومن رابط
            التقديم الرسمي. لا تعتمد على وسيط مجهول أو حساب شخصي في
            مواقع التواصل الاجتماعي.
        </p>

        <a class="button back" href="/spain">
            🇪🇸 {{ $lang === "es" ? "Volver a la guía de España" : ($lang === "fr" ? "Retour au guide de l’Espagne" : "العودة إلى دليل إسبانيا") }}
        </a>

        <a class="button back" href="/cap">
            🎓 {{ $lang === "es" ? "Centros CAP" : ($lang === "fr" ? "Centres CAP" : "مراكز CAP") }}
        </a>

        <a class="button back" href="/">
            🏠 {{ $lang === "es" ? "Inicio" : ($lang === "fr" ? "Accueil" : "الرئيسية") }}
        </a>
    </div>

</div>

<footer>
    © 2026 Edriouche Truck Job — من السائق إلى السائق 🚛
</footer>


<!-- EDRIOUCHE_LODISNA_BAHI_GEN_ADEC_2026 -->
@php
    $lang = session('locale', 'ar');
@endphp

@php
    $newCompanies = [
        'ar' => [
            'title' => '⭐ شركات تستحق اهتمام السائق المغربي',
            'lodisna_title' => '🇪🇸 Lodisna',
            'lodisna_sub' => 'فرصة مهمة للسائقين المغاربة C+E',
            'lodisna_1' => 'شركة إسبانية للنقل تبحث عن سائقي الشاحنات C+E، وتوفر تكويناً مستمراً للسائقين.',
            'lodisna_2' => 'وفق معلومات الشركة الرسمية، يمكنها عند الحاجة مساعدة المرشحين في الحصول على E وCAP وبطاقة التاكوجراف اللازمة للعمل لديها.',
            'lodisna_3' => 'كما أن للشركة مكتباً في طنجة بالمغرب، وهو ما يجعلها من الشركات المهمة التي يمكن للسائق المغربي التواصل معها مباشرة.',
            'lodisna_warn' => 'المساعدة في CAP أو الوثائق تكون حسب حالة المرشح وشروط الشركة، ولا تعني ضمان عقد عمل أو تأشيرة.',
            'job_link' => 'صفحة التوظيف الرسمية',
            'bahi_title' => '🇪🇸 Bahí Grup',
            'bahi_sub' => 'النقل الدولي — سائقي C+E',
            'bahi_1' => 'شركة إسبانية تبحث عن سائقي النقل الدولي، وتطلب رخصة E وخبرة في النقل.',
            'bahi_2' => 'استمارة التوظيف الرسمية تتضمن النقل الدولي، Trailer وCisterna وFrigorífico، كما تتضمن المغرب ضمن البلدان التي يمكن للسائق أن يكون قد عمل فيها.',
            'bahi_3' => 'مناسبة للسائق المغربي ذي الخبرة في النقل الدولي، خصوصاً المغرب–أوروبا.',
            'bahi_warn' => 'وجود المغرب في استمارة التوظيف لا يعني أن الشركة أعلنت ضمان توظيف كل سائق مغربي؛ يجب التأكد من الشروط والشواغر الحالية مباشرة مع الشركة.',
            'genadec_title' => '🇲🇦🤝🇪🇸 مسار GENADEC – ASTIC',
            'genadec_sub' => 'التكوين والربط مع فرص العمل في إسبانيا',
            'genadec_1' => 'توجد شراكة مذكورة في تقرير ASTIC لتسهيل توظيف السائقين المغاربة، وتشمل البحث عن المرشحين وانتقاءهم والمقابلات والتكوين والإجراءات المرتبطة بالهجرة والتصاريح وCAP.',
            'genadec_2' => 'كما تقدم GENADEC المغربية برنامجاً للسائقين المهنيين المتجهين إلى الأسواق الدولية، ومنها إسبانيا، مع التكوين في القواعد الأوروبية والاستعداد لـ Code 95.',
            'genadec_link' => 'برنامج GENADEC للسائقين المهنيين',
            'warning_title' => '⚠️ تنبيه للسائقين',
            'warning_1' => 'وجود الشركة في هذه الصفحة لا يعني وجود شاغر متاح دائماً، ولا يعني ضمان عقد عمل أو تأشيرة أو قبول السائق بدون CAP.',
            'warning_2' => 'تحقق دائماً من شروط الشركة مباشرة، ولا تدفع المال لأي وسيط مقابل وعد بعقد أو تأشيرة قبل التأكد من الجهة الرسمية.',
            'goal' => '🎯 هدف Edriouche Truck Job: الوصول إلى فرص حقيقية وقانونية للسائقين المغاربة، بدون وسطاء وبدون وعود كاذبة.'
        ],
        'es' => [
            'title' => '⭐ Empresas de especial interés para conductores marroquíes',
            'lodisna_title' => '🇪🇸 Lodisna',
            'lodisna_sub' => 'Una oportunidad importante para conductores marroquíes C+E',
            'lodisna_1' => 'Empresa española de transporte que busca conductores de camión C+E y ofrece formación continua.',
            'lodisna_2' => 'Según la información oficial de la empresa, puede ayudar, cuando sea necesario, a los candidatos a obtener E, CAP y la tarjeta de tacógrafo necesaria para incorporarse a la empresa.',
            'lodisna_3' => 'La empresa también dispone de una oficina en Tánger, Marruecos, lo que facilita el contacto directo de los conductores marroquíes.',
            'lodisna_warn' => 'La ayuda con CAP o documentación depende de la situación del candidato y de las condiciones de la empresa; no significa garantía de contrato o visado.',
            'job_link' => 'Página oficial de empleo',
            'bahi_title' => '🇪🇸 Bahí Grup',
            'bahi_sub' => 'Transporte internacional — conductores C+E',
            'bahi_1' => 'Empresa española que busca conductores para transporte internacional y solicita permiso E y experiencia en transporte.',
            'bahi_2' => 'El formulario oficial incluye transporte internacional, tráiler, cisterna y frigorífico, y también incluye Marruecos entre los países en los que el conductor puede haber trabajado.',
            'bahi_3' => 'Puede ser de interés para conductores marroquíes con experiencia en transporte internacional, especialmente Marruecos–Europa.',
            'bahi_warn' => 'La presencia de Marruecos en el formulario no significa que la empresa garantice la contratación de todos los conductores marroquíes; hay que confirmar las condiciones y vacantes directamente.',
            'genadec_title' => '🇲🇦🤝🇪🇸 Vía GENADEC – ASTIC',
            'genadec_sub' => 'Formación y conexión con oportunidades de empleo en España',
            'genadec_1' => 'El informe de ASTIC menciona una colaboración para facilitar la contratación de conductores marroquíes, incluyendo búsqueda, selección, entrevistas, formación y procedimientos relacionados con inmigración, permisos y CAP.',
            'genadec_2' => 'GENADEC también ofrece un programa para conductores profesionales orientados a mercados internacionales, incluido España, con formación sobre normas europeas y preparación para Code 95.',
            'genadec_link' => 'Programa oficial de GENADEC para conductores profesionales',
            'warning_title' => '⚠️ Aviso para los conductores',
            'warning_1' => 'La presencia de una empresa en esta página no significa que exista siempre una vacante disponible, ni garantiza contrato, visado o aceptación de conductores sin CAP.',
            'warning_2' => 'Comprueba siempre las condiciones directamente con la empresa y no pagues a intermediarios por promesas de contrato o visado sin verificar primero la entidad oficial.',
            'goal' => '🎯 Objetivo de Edriouche Truck Job: encontrar oportunidades reales y legales para conductores marroquíes, sin intermediarios ni falsas promesas.'
        ],
        'fr' => [
            'title' => '⭐ Entreprises particulièrement intéressantes pour les conducteurs marocains',
            'lodisna_title' => '🇪🇸 Lodisna',
            'lodisna_sub' => 'Une opportunité importante pour les conducteurs marocains C+E',
            'lodisna_1' => 'Entreprise espagnole de transport qui recherche des conducteurs de poids lourds C+E et propose une formation continue.',
            'lodisna_2' => 'Selon les informations officielles de l’entreprise, elle peut, si nécessaire, aider les candidats à obtenir E, CAP et la carte tachygraphe nécessaires pour rejoindre l’entreprise.',
            'lodisna_3' => 'L’entreprise dispose également d’un bureau à Tanger, au Maroc, ce qui facilite le contact direct avec les conducteurs marocains.',
            'lodisna_warn' => 'L’aide concernant le CAP ou les documents dépend de la situation du candidat et des conditions de l’entreprise ; elle ne constitue pas une garantie de contrat ou de visa.',
            'job_link' => 'Page officielle de recrutement',
            'bahi_title' => '🇪🇸 Bahí Grup',
            'bahi_sub' => 'Transport international — conducteurs C+E',
            'bahi_1' => 'Entreprise espagnole qui recherche des conducteurs pour le transport international et demande le permis E ainsi qu’une expérience dans le transport.',
            'bahi_2' => 'Le formulaire officiel comprend le transport international, la remorque, la citerne et le frigorifique, et mentionne également le Maroc parmi les pays dans lesquels le conducteur peut avoir travaillé.',
            'bahi_3' => 'Peut être intéressante pour les conducteurs marocains ayant une expérience du transport international, notamment Maroc–Europe.',
            'bahi_warn' => 'La présence du Maroc dans le formulaire ne signifie pas que l’entreprise garantit l’embauche de tous les conducteurs marocains ; les conditions et les postes disponibles doivent être vérifiés directement.',
            'genadec_title' => '🇲🇦🤝🇪🇸 Parcours GENADEC – ASTIC',
            'genadec_sub' => 'Formation et mise en relation avec des opportunités d’emploi en Espagne',
            'genadec_1' => 'Le rapport d’ASTIC mentionne une collaboration visant à faciliter le recrutement de conducteurs marocains, notamment la recherche, la sélection, les entretiens, la formation et les démarches liées à l’immigration, aux autorisations et au CAP.',
            'genadec_2' => 'GENADEC propose également un programme destiné aux conducteurs professionnels orientés vers les marchés internationaux, dont l’Espagne, avec une formation aux règles européennes et une préparation au Code 95.',
            'genadec_link' => 'Programme officiel de GENADEC pour les conducteurs professionnels',
            'warning_title' => '⚠️ Avertissement aux conducteurs',
            'warning_1' => 'La présence d’une entreprise sur cette page ne signifie pas qu’un poste est toujours disponible et ne garantit ni contrat de travail, ni visa, ni acceptation d’un conducteur sans CAP.',
            'warning_2' => 'Vérifiez toujours les conditions directement auprès de l’entreprise et ne payez aucun intermédiaire pour une promesse de contrat ou de visa sans vérifier d’abord l’organisme officiel.',
            'goal' => '🎯 Objectif d’Edriouche Truck Job : trouver des opportunités réelles et légales pour les conducteurs marocains, sans intermédiaires ni fausses promesses.'
        ]
    ];
    $t = $newCompanies[$lang] ?? $newCompanies['ar'];
@endphp

<section style="max-width:1000px;margin:40px auto;padding:25px;background:#fffaf0;border:2px solid #d2a84a;border-radius:18px;direction:{{ $lang === 'ar' ? 'rtl' : 'ltr' }};text-align:{{ $lang === 'ar' ? 'right' : 'left' }};line-height:2;">

    <h2 style="color:#6b4c07;text-align:center;">{{ $t['title'] }}</h2>

    <div style="margin-top:25px;padding:22px;background:#ffffff;border:1px solid #d2a84a;border-radius:15px;">
        <h2>{{ $t['lodisna_title'] }}</h2>
        <p><strong>{{ $t['lodisna_sub'] }}</strong></p>
        <p>{{ $t['lodisna_1'] }}</p>
        <p>{{ $t['lodisna_2'] }}</p>
        <p>{{ $t['lodisna_3'] }}</p>
        <p><strong>⚠️ {{ $t['lodisna_warn'] }}</strong></p>
        <p>
            🌐 <a href="https://lodisna.com/contratacion/" target="_blank" rel="noopener">{{ $t['job_link'] }}</a>
            <br>
            📍 +212 539 940 932
            <br>
            ✉️ infoma@lodisna.com
        </p>
    </div>

    <div style="margin-top:25px;padding:22px;background:#ffffff;border:1px solid #d2a84a;border-radius:15px;">
        <h2>{{ $t['bahi_title'] }}</h2>
        <p><strong>{{ $t['bahi_sub'] }}</strong></p>
        <p>{{ $t['bahi_1'] }}</p>
        <p>{{ $t['bahi_2'] }}</p>
        <p><strong>{{ $t['bahi_3'] }}</strong></p>
        <p><strong>⚠️ {{ $t['bahi_warn'] }}</strong></p>
        <p>
            🌐 <a href="https://www.bahisa.es/es/buscamos-profesionales/" target="_blank" rel="noopener">{{ $t['job_link'] }}</a>
        </p>
    </div>

    <div style="margin-top:25px;padding:22px;background:#f8f1e7;border:2px solid #b08d2c;border-radius:15px;">
        <h2>{{ $t['genadec_title'] }}</h2>
        <p><strong>{{ $t['genadec_sub'] }}</strong></p>
        <p>{{ $t['genadec_1'] }}</p>
        <p>{{ $t['genadec_2'] }}</p>
        <p>
            🌐 <a href="https://genadec.com/pf/conducteurs-professionnels-a-linternational/" target="_blank" rel="noopener">{{ $t['genadec_link'] }}</a>
        </p>
    </div>

    <div style="margin-top:25px;padding:20px;background:#fff3cd;border:2px solid #d6a800;border-radius:15px;">
        <p><strong>{{ $t['warning_title'] }}</strong></p>
        <p>{{ $t['warning_1'] }}</p>
        <p>{{ $t['warning_2'] }}</p>
        <p><strong>{{ $t['goal'] }}</strong></p>
    </div>

</section>
<!-- /EDRIOUCHE_LODISNA_BAHI_GEN_ADEC_2026 -->

<section style="max-width:1000px;margin:35px auto;padding:24px;background:#f8f1e7;border:2px solid #d2a84a;border-radius:16px;direction:rtl;">
@php $locale=app()->getLocale(); @endphp

<h2 style="text-align:center;">🇪🇸 {{ $locale==="es" ? "Empresas con oportunidades para conductores" : ($locale==="fr" ? "Entreprises proposant des opportunités aux conducteurs" : "شركات لديها فرص للسائقين") }}</h2>

<div style="background:#fff;padding:18px;border-radius:12px;margin:15px 0;">
<h3>🚛 Grupo Sesé</h3>
<p>{{ $locale==="es" ? "Grupo de transporte y logística con portal oficial de empleo y puestos publicados en España." : ($locale==="fr" ? "Groupe de transport et logistique avec portail officiel d’emploi et des postes publiés en Espagne." : "مجموعة للنقل واللوجستيك لديها بوابة توظيف رسمية وفرص منشورة في إسبانيا.") }}</p>
<a href="https://empleo.gruposese.com/" target="_blank" rel="noopener" style="display:inline-block;background:#d2a84a;color:#111;padding:11px 20px;border-radius:9px;text-decoration:none;font-weight:bold;">{{ $locale==="es" ? "Ver ofertas oficiales" : ($locale==="fr" ? "Voir les offres officielles" : "عرض عروض العمل الرسمية") }}</a>
</div>

<h2 style="text-align:center;margin-top:30px;">🎓 {{ $locale==="es" ? "Formación y empleo para conductores" : ($locale==="fr" ? "Formation et emploi pour conducteurs" : "تكوين وتوظيف السائقين") }}</h2>

<div style="background:#fff;padding:18px;border-radius:12px;margin:15px 0;">
<h3>🎓 Centro de Formación RUTA</h3>
<p>{{ $locale==="es" ? "Centro de formación para permisos C y C+E y cursos CAP. RUTA también dispone de un servicio de empleo para alumnos y antiguos alumnos, con ofertas de empresas de transporte." : ($locale==="fr" ? "Centre de formation pour les permis C et C+E et les cours CAP. RUTA dispose également d’un service d’emploi pour ses élèves et anciens élèves, avec des offres d’entreprises de transport." : "مركز للتكوين في رخص C وC+E ودورات CAP. كما تتوفر لدى RUTA خدمة توظيف للطلاب والخريجين السابقين، مع عروض من شركات النقل.") }}</p>
<a href="https://centrodeformacionruta.es/empleo/" target="_blank" rel="noopener" style="display:inline-block;background:#d2a84a;color:#111;padding:11px 20px;border-radius:9px;text-decoration:none;font-weight:bold;">{{ $locale==="es" ? "Ver formación y empleo" : ($locale==="fr" ? "Voir la formation et l’emploi" : "عرض التكوين والتوظيف") }}</a>
</div>

<p style="font-size:14px;text-align:center;margin-top:22px;">{{ $locale==="es" ? "Aviso: aparecer en esta página no significa que exista una vacante para todos los candidatos ni garantiza contrato, visado o contratación." : ($locale==="fr" ? "Attention : la présence sur cette page ne garantit pas un poste pour chaque candidat, ni un contrat, un visa ou un recrutement." : "تنبيه: إدراج الجهة في هذه الصفحة لا يعني وجود شاغر لكل المتقدمين ولا يضمن عقد عمل أو تأشيرة أو توظيفًا.") }}</p>
</section>

</body>
</html>
